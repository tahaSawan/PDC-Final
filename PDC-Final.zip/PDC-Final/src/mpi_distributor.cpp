#include "../include/mpi_distributor.hpp"
#include <metis.h>
#include <algorithm>
#include <numeric>
#include <unordered_set>
#include <stdexcept>

MPIDistributor::MPIDistributor(DynamicGraph& graph) : original_graph(graph) {
    int initialized;
    MPI_Initialized(&initialized);
    if (!initialized) {
        int argc = 0;
        char** argv = nullptr;
        MPI_Init(&argc, &argv);
    }
    
    // Initialize METIS data structures
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    if (rank == 0) {
        original_graph.get_metis_xadj();  // Prepare METIS data
        original_graph.get_metis_adjncy();
    }
}

MPIDistributor::~MPIDistributor() {
    int finalized;
    MPI_Finalized(&finalized);
    if (!finalized) {
        MPI_Finalize();
    }
}

void MPIDistributor::partition_and_distribute() {
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    
    idx_t nVertices = original_graph.node_count();
    idx_t nParts = size;
    idx_t objval;
    node_partitions.resize(nVertices);
    
    if (rank == 0) {
        idx_t* xadj = original_graph.get_metis_xadj();
        idx_t* adjncy = original_graph.get_metis_adjncy();
        
        idx_t nConst = 1;
        idx_t options[METIS_NOPTIONS];
        METIS_SetDefaultOptions(options);
        options[METIS_OPTION_OBJTYPE] = METIS_OBJTYPE_CUT;
        options[METIS_OPTION_CONTIG] = 1;
        
        int ret = METIS_PartGraphKway(&nVertices, &nConst, xadj, adjncy, 
                                    NULL, NULL, NULL, &nParts, 
                                    NULL, NULL, NULL, &objval, node_partitions.data());
        if (ret != METIS_OK) {
            throw std::runtime_error("METIS partitioning failed");
        }
    }
    
    MPI_Bcast(node_partitions.data(), nVertices, MPI_INT, 0, MPI_COMM_WORLD);
    local_partition = original_graph.extract_partition(node_partitions, rank);
    gather_partition_info();
}

void MPIDistributor::gather_partition_info() {
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    
    // First, identify local boundary nodes
    std::unordered_map<int, std::unordered_set<int>> local_boundaries;
    
    for (int node = 0; node < original_graph.node_count(); node++) {
        if (node_partitions[node] == rank) {
            for (int neighbor : original_graph.get_neighbors(node)) {
                if (node_partitions[neighbor] != rank) {
                    local_boundaries[node].insert(node_partitions[neighbor]);
                }
            }
        }
    }
    
    // Gather all boundary information to rank 0
    std::vector<int> boundary_counts(size);
    int my_count = local_boundaries.size();
    MPI_Gather(&my_count, 1, MPI_INT, boundary_counts.data(), 1, MPI_INT, 0, MPI_COMM_WORLD);
    
    // Prepare send buffer
    std::vector<int> send_buffer;
    for (const auto& [node, parts] : local_boundaries) {
        send_buffer.push_back(node);
        send_buffer.push_back(static_cast<int>(parts.size()));
        for (int part : parts) {
            send_buffer.push_back(part);
        }
    }
    
    // Gather all boundary data to rank 0
    std::vector<int> all_boundaries;
    if (rank == 0) {
        int total = std::accumulate(boundary_counts.begin(), boundary_counts.end(), 0);
        all_boundaries.resize(total * 3);  // Rough estimate
    }
    
    MPI_Gather(send_buffer.data(), send_buffer.size(), MPI_INT,
              all_boundaries.data(), send_buffer.size(), MPI_INT,
              0, MPI_COMM_WORLD);
    
    // Process boundary data on rank 0 and broadcast
    if (rank == 0) {
        boundary_nodes.clear();
        size_t pos = 0;
        for (int p = 0; p < size; p++) {
            int count = boundary_counts[p];
            for (int i = 0; i < count; i++) {
                int node = all_boundaries[pos++];
                int num_parts = all_boundaries[pos++];
                for (int j = 0; j < num_parts; j++) {
                    boundary_nodes[node].push_back(all_boundaries[pos++]);
                }
            }
        }
    }
    
    // Broadcast boundary nodes to all processes
    int num_boundary_nodes = boundary_nodes.size();
    MPI_Bcast(&num_boundary_nodes, 1, MPI_INT, 0, MPI_COMM_WORLD);
    
    if (rank != 0) boundary_nodes.clear();
    
    for (int i = 0; i < num_boundary_nodes; i++) {
        int node, num_parts;
        if (rank == 0) {
            auto it = boundary_nodes.begin();
            std::advance(it, i);
            node = it->first;
            num_parts = it->second.size();
        }
        
        MPI_Bcast(&node, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&num_parts, 1, MPI_INT, 0, MPI_COMM_WORLD);
        
        std::vector<int> parts(num_parts);
        if (rank == 0) {
            parts = boundary_nodes[node];
        }
        
        MPI_Bcast(parts.data(), num_parts, MPI_INT, 0, MPI_COMM_WORLD);
        
        if (rank != 0) {
            boundary_nodes[node] = parts;
        }
    }
}

void MPIDistributor::synchronize_boundaries() {
    exchange_boundary_data();
}

void MPIDistributor::exchange_boundary_data() {
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    
    // For each boundary node, exchange data with other partitions
    for (const auto& [node, partitions] : boundary_nodes) {
        if (node_partitions[node] == rank) {
            // This is our node, send data to other partitions
            for (int part : partitions) {
                if (part != rank) {
                    // Prepare data to send
                    auto node_data = local_partition.get_node_data(node);
                    MPI_Send(&node_data, sizeof(DynamicGraph::NodeData), MPI_BYTE, 
                            part, 0, MPI_COMM_WORLD);
                }
            }
        } else {
            // This node belongs to another partition, receive updates
            for (int part : partitions) {
                if (part == rank) {
                    DynamicGraph::NodeData received_data;
                    MPI_Status status;
                    MPI_Recv(&received_data, sizeof(DynamicGraph::NodeData), MPI_BYTE,
                            MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
                    local_partition.update_node(node, received_data);
                }
            }
        }
    }
}

DynamicGraph& MPIDistributor::get_local_partition() {
    return local_partition;
}

const std::unordered_map<int, std::vector<int>>& MPIDistributor::get_boundary_nodes() const {
    return boundary_nodes;
}