#pragma once
#include "graph.hpp"
#include <omp.h>
#include <vector>
#include <queue>
#include <limits>
#include <atomic>

class SOSPEngine {
    DynamicGraph& graph;
    std::vector<double> distances;
    std::vector<int> predecessors;
    std::vector<std::atomic<bool>> in_queue;

public:
    explicit SOSPEngine(DynamicGraph& g) : graph(g), in_queue(g.node_count()) {}

    void compute(int source) {
        const double INF = std::numeric_limits<double>::max();
        distances.assign(graph.node_count(), INF);
        predecessors.assign(graph.node_count(), -1);
        
        for (auto& flag : in_queue) {
            flag.store(false);
        }
        distances[source] = 0.0;

        std::vector<std::priority_queue<std::pair<double, int>,
                      std::vector<std::pair<double, int>>,
                      std::greater<>>> thread_queues(omp_get_max_threads());
        thread_queues[0].emplace(0.0, source);
        in_queue[source].store(true);

        bool active = true;
        #pragma omp parallel shared(active)
        {
            int tid = omp_get_thread_num();
            
            while (active) {
                while (!thread_queues[tid].empty()) {
                    auto [current_dist, u] = thread_queues[tid].top();
                    thread_queues[tid].pop();
                    in_queue[u].store(false);

                    if (current_dist > distances[u]) continue;

                    #pragma omp for schedule(dynamic, 32)
                    for (const auto& edge : graph.get_edges(u)) {
                        double new_dist = current_dist + edge.weights[0];

                        if (new_dist < distances[edge.target]) {
                            #pragma omp critical
                            {
                                if (new_dist < distances[edge.target]) {
                                    distances[edge.target] = new_dist;
                                    predecessors[edge.target] = u;
                                }
                            }

                            bool expected = false;
                            if (!in_queue[edge.target].load() && 
                                in_queue[edge.target].compare_exchange_strong(expected, true)) {
                                thread_queues[tid].emplace(new_dist, edge.target);
                            }
                        }
                    }
                }

                #pragma omp barrier
                #pragma omp single
                {
                    active = false;
                    for (const auto& q : thread_queues) {
                        if (!q.empty()) {
                            active = true;
                            break;
                        }
                    }
                }
            }
        }
    }

    void update(const std::vector<int>& changed_edges) {
        std::vector<bool> affected(graph.node_count(), false);
        for (int e : changed_edges) {
            affected[e] = true;
        }

        #pragma omp parallel for schedule(dynamic, 32)
        for (int u = 0; u < graph.node_count(); ++u) {
            if (affected[u]) {
                for (const auto& edge : graph.get_edges(u)) {
                    double new_dist = distances[u] + edge.weights[0];
                    if (new_dist < distances[edge.target]) {
                        #pragma omp critical
                        {
                            if (new_dist < distances[edge.target]) {
                                distances[edge.target] = new_dist;
                                predecessors[edge.target] = u;
                            }
                        }
                    }
                }
            }
        }
    }

    double get_distance(int node) const { 
        if (node < 0 || node >= distances.size()) {
            throw std::out_of_range("Node ID out of range");
        }
        return distances[node]; 
    }
    
    const std::vector<double>& get_all_distances() const { return distances; }
};